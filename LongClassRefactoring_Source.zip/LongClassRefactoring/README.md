# LongClassExample Refactoring Submission

This repository contains the refactored solution for the LongClassExample / MegaSystemManager exercise.

## How to run

```bash
cd src
javac *.java
java App
```

## Notes

- The original God Class was split into smaller classes using Single Responsibility Principle.
- Type codes were replaced with enums.
- Long parameter list was replaced with `OrderRequest`.
- Long methods were split into services.
- File handling now uses try-with-resources.

## Repository Link

Replace this placeholder after uploading to GitHub:

https://github.com/your-username/long-class-refactoring
